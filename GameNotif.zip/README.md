# GameNotif v1.0 — Android starter project

Starter source for an Android notification manager for Android 8.0+ (tested target: Android 16 configuration).

## Included in this starter
- Dark mode default and Light/Dark toggle.
- Installed launchable app list with per-app ON/OFF selection.
- Notification Listener service.
- Local notification history.
- Conservative sensitive-content blocking.
- Manual share action for WhatsApp from history.
- No game is preselected.

## Important WhatsApp limitation
WhatsApp personal accounts do not provide a supported public API for silently sending a message from a third-party Android app. This starter therefore does **not** auto-send messages. A user must tap Share and then Send in WhatsApp. Do not use Accessibility automation to bypass this confirmation.

## Security and privacy
- Notification content is stored locally in app SharedPreferences.
- `allowBackup=false` is set to reduce backup exposure.
- OTP/password/banking-related keywords and digit sequences are blocked before history storage.
- This keyword filter is a best-effort safeguard, not a guarantee. Review the source and test with dummy notifications only.
- Notification access is a powerful permission. Enable it only if you trust the app build.
- No network permission or analytics SDK is included.

## Build
1. Install Android Studio with Android SDK Platform 36.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on your own iQOO Z10 for testing.

Use a current stable Android Studio/Gradle environment. If Android Studio suggests a compatible Gradle or plugin update, review it before accepting.

## First run
1. Open GameNotif.
2. Tap **Aktifkan akses notifikasi** and enable GameNotif in Android notification access settings.
3. Open **Aplikasi** and turn ON only the apps you want to monitor.
4. Trigger a harmless test notification.
5. Open **Riwayat** and use **Bagikan ke WhatsApp** if you want to forward it manually.

## Known limitations / next work
- Background photo picker, font packs, sound customization and export/clear history are not yet implemented.
- App list currently shows launchable installed apps. Android package visibility rules may limit what can be listed; the project intentionally avoids broad package visibility permissions.
- Some OEM battery restrictions may stop background listener reliability. Configure battery usage for GameNotif if needed.
- This source project is not a prebuilt APK and has not been compiled or security-audited in this environment.


## Build from a phone using GitHub Actions
This project includes `.github/workflows/android.yml`.
1. Create a GitHub account and a new repository.
2. Upload the contents of this project ZIP to the repository (not the ZIP as a single file).
3. Open the repository's **Actions** tab.
4. Select **Build GameNotif APK** and tap **Run workflow** (or push to `main`).
5. When the run completes, open it and download the `GameNotif-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`.
GitHub account/repository visibility and Actions availability may vary. A debug APK is for testing, not a production security-certified release.
