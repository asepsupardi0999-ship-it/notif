package com.example.gamenotif

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class AppChoice(val packageName: String, val label: String, val enabled: Boolean)
data class HistoryItem(val app: String, val packageName: String, val title: String, val body: String, val time: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameNotifApp() }
    }
}

@Composable
fun GameNotifApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("gamenotif", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var accent by remember { mutableStateOf(prefs.getString("accent", "Green") ?: "Green") }
    var filterText by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val colors = if (dark) darkColorScheme(
        primary = Color(0xFF43D99A), background = Color(0xFF101216),
        surface = Color(0xFF1A1F25), onBackground = Color.White, onSurface = Color.White
    ) else lightColorScheme(primary = Color(0xFF16865A))
    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Aplikasi", "Riwayat", "Tampilan").forEachIndexed { i, name ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i; refresh++ },
                            icon = { Icon(
                                when(i) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Apps; 2 -> Icons.Default.History; else -> Icons.Default.Palette },
                                contentDescription = name
                            ) },
                            label = { Text(name) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), onPermission = {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }, onRefresh = { refresh++ })
                1 -> AppsScreen(Modifier.padding(padding), filterText, { filterText = it }, refresh)
                2 -> HistoryScreen(Modifier.padding(padding), refresh)
                else -> AppearanceScreen(Modifier.padding(padding), dark, { dark = it; prefs.edit().putBoolean("dark", it).apply() }, accent, {
                    accent = it; prefs.edit().putString("accent", it).apply()
                })
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onPermission: () -> Unit, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val enabled = remember { mutableStateOf(isListenerEnabled(context)) }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("GameNotif", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Penerus notifikasi • Android", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("STATUS PEMANTAUAN", style = MaterialTheme.typography.labelMedium)
                Text(if (enabled.value) "Izin notifikasi aktif" else "Perlu izin notifikasi", style = MaterialTheme.typography.titleLarge)
                Text("GameNotif hanya membaca notifikasi dari aplikasi yang kamu aktifkan. Data disimpan lokal di perangkat.")
                Button(onClick = { onPermission(); enabled.value = isListenerEnabled(context) }) {
                    Text(if (enabled.value) "Kelola izin" else "Aktifkan akses notifikasi")
                }
                OutlinedButton(onClick = { enabled.value = isListenerEnabled(context); onRefresh() }) { Text("Periksa status") }
            }
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Keamanan aktif", fontWeight = FontWeight.SemiBold)
                Text("OTP, kode verifikasi, kata sandi, dan kata kunci transaksi/perbankan akan diblokir dari riwayat dan penerusan.")
            }
        }
        Text("Catatan WhatsApp", fontWeight = FontWeight.SemiBold)
        Text("Android tidak mengizinkan aplikasi pihak ketiga mengirim pesan otomatis ke chat WhatsApp pribadi secara resmi. Versi awal menyediakan tombol berbagi ke WhatsApp; kamu tetap menekan Kirim sendiri.")
    }
}

@Composable
fun AppsScreen(modifier: Modifier, query: String, onQuery: (String) -> Unit, refresh: Int) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("gamenotif", Context.MODE_PRIVATE) }
    val apps = remember(refresh) {
        val pm = context.packageManager
        val own = context.packageName
        pm.getInstalledApplications(0)
            .filter { it.packageName != own && pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { info ->
                val label = pm.getApplicationLabel(info).toString()
                AppChoice(info.packageName, label, prefs.getBoolean("app_${info.packageName}", false))
            }.sortedBy { it.label.lowercase() }
    }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Pilih aplikasi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Tidak ada game yang dipilih otomatis. Aktifkan sendiri aplikasi yang ingin dipantau.")
        OutlinedTextField(query, onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Cari aplikasi...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(apps.filter { it.label.contains(query, true) }) { app ->
                var checked by remember(app.packageName) { mutableStateOf(app.enabled) }
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app.label, fontWeight = FontWeight.Medium)
                        Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                    }
                    Switch(checked, onCheckedChange = {
                        checked = it
                        prefs.edit().putBoolean("app_${app.packageName}", it).apply()
                    })
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun HistoryScreen(modifier: Modifier, refresh: Int) {
    val context = LocalContext.current
    val history = remember(refresh) { readHistory(context) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Riwayat notifikasi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Hanya notifikasi yang lolos filter keamanan dan berasal dari aplikasi pilihan.")
        if (history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada notifikasi tersimpan.")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { item ->
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(item.app, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            if (item.title.isNotBlank()) Text(item.title, fontWeight = FontWeight.SemiBold)
                            Text(item.body)
                            OutlinedButton(onClick = {
                                val msg = "${item.app}\n${item.title}\n${item.body}".trim()
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg)
                                    setPackage("com.whatsapp")
                                }
                                try { context.startActivity(send) } catch (_: Exception) {
                                    val chooser = Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg)
                                    }, "Bagikan notifikasi")
                                    context.startActivity(chooser)
                                }
                            }) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("Bagikan ke WhatsApp") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppearanceScreen(modifier: Modifier, dark: Boolean, onDark: (Boolean) -> Unit, accent: String, onAccent: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Tampilan", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Dark Mode"); Text("Tampilan awal GameNotif") }
            Switch(dark, onDark)
        }
        Text("Warna aksen", fontWeight = FontWeight.SemiBold)
        listOf("Green", "Blue", "Purple", "Red").forEach { color ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = accent == color, onClick = { onAccent(color) })
                Text(color)
            }
        }
        Text("Latar foto dan pilihan font tambahan direncanakan untuk pembaruan berikutnya.")
    }
}

fun isListenerEnabled(context: Context): Boolean {
    val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
    return flat.contains(context.packageName)
}

fun readHistory(context: Context): List<HistoryItem> {
    val raw = context.getSharedPreferences("gamenotif", Context.MODE_PRIVATE).getString("history", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryItem(o.optString("app"), o.optString("pkg"), o.optString("title"), o.optString("body"), o.optLong("time"))
        }.reversed()
    } catch (_: Exception) { emptyList() }
}
