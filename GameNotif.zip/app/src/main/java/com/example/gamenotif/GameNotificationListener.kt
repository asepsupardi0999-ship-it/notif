package com.example.gamenotif

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class GameNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName || pkg == "com.whatsapp") return

        val prefs = getSharedPreferences("gamenotif", MODE_PRIVATE)
        if (!prefs.getBoolean("app_$pkg", false)) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val content = listOf(title, body, big).filter { it.isNotBlank() }.joinToString(" ")
        if (content.isBlank() || SensitiveFilter.isSensitive(content)) return

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }

        synchronized(this) {
            val old = try { JSONArray(prefs.getString("history", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
            val item = JSONObject().apply {
                put("app", appName); put("pkg", pkg); put("title", title)
                put("body", if (big.isNotBlank()) big else body); put("time", System.currentTimeMillis())
            }
            val next = JSONArray()
            next.put(item)
            for (i in 0 until minOf(old.length(), 99)) next.put(old.getJSONObject(i))
            prefs.edit().putString("history", next.toString()).apply()
        }
    }
}

object SensitiveFilter {
    private val patterns = listOf(
        Regex("""\b(otp|one[- ]time password|verification code|security code|passcode|password|kata sandi|kode verifikasi|kode otp)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(pin|cvv|cvc|rekening|saldo|transfer|transaksi|bank|kartu kredit|debit|payment|paid|pembayaran)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b\d{4,8}\b""")
    )
    fun isSensitive(text: String): Boolean = patterns.any { it.containsMatchIn(text) }
}
